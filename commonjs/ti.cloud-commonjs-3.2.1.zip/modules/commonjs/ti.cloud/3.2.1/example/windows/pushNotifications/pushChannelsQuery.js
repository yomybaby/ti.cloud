windowFunctions['Push Channels Query'] = function (evt) {
    var win = createWindow();
    var offset = addBackButton(win);
    var admin_logged_in = false;
    var content = Ti.UI.createScrollView({
        top: offset + u,
        contentHeight: 'auto',
        layout: 'vertical'
    });
    win.add(content);

    Cloud.Users.showMe(function (e) {
        if (e.success && e.users[0].admin === 'true') {
            admin_logged_in = true;
            var user_id = Ti.UI.createTextField({
                hintText: 'user_id',
                top: 10 + u, left: 10 + u, right: 10 + u,
                height: 40 + u,
                borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
                autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
                autocorrect: false
            });
            content.add(user_id);
        }
    });

    var button = Ti.UI.createButton({
        title: 'Query',
        top: 10 + u, left: 10 + u, right: 10 + u, bottom: 10 + u,
        height: 40 + u
    });
    content.add(button);

    var fields = [ user_id ];

    function submitForm() {
        for (var i = 0; i < fields.length; i++) {
            if (!fields[i].value.length) {
                fields[i].focus();
                return;
            }
            fields[i].blur();
        }
        button.hide();

        var params = {};
        if (admin_logged_in) {
            params.user_id = user_id.value
        }
        Cloud.PushChannels.query(params, function (e) {
            if (e.success) {
                user_id.value = '';
                alert('Query: ' + JSON.stringify(e));
            } else {
                error(e);
            }
            button.show();
        });
    }

    button.addEventListener('click', submitForm);
    for (var i = 0; i < fields.length; i++) {
        fields[i].addEventListener('return', submitForm);
    }

    win.open();
};